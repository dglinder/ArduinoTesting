/*
* This is port of Dean Camera's ATOMIC_BLOCK macros for AVR to ARM Cortex M3 
* v1.0
* Mark Pendrith, Nov 27, 2012.
*
* From Mark:
* &gt;When I ported the macros I emailed Dean to ask what attribution would be
* &gt;appropriate, and here is his response:
* &gt;
* &gt;&gt;Mark,
* &gt;&gt;I think it's great that you've ported the macros; consider them
* &gt;&gt;public domain, to do with whatever you wish. I hope you find them &gt;useful .
* &gt;&gt;
* &gt;&gt;Cheers!
* &gt;&gt;- Dean 
*/

#ifdef __arm__ 
#ifndef _CORTEX_M3_ATOMIC_H_
#define _CORTEX_M3_ATOMIC_H_

static __inline__ uint32_t __get_primask(void) \
{ uint32_t primask = 0; \
  __asm__ volatile (&quot;MRS %[result], PRIMASK\n\t&quot;:[result]&quot;=r&quot;(primask)::); \
  return primask; } // returns 0 if interrupts enabled, 1 if disabled

static __inline__ void __set_primask(uint32_t setval) \
{ __asm__ volatile (&quot;MSR PRIMASK, %[value]\n\t&quot;&quot;dmb\n\t&quot;&quot;dsb\n\t&quot;&quot;isb\n\t&quot;::[value]&quot;r&quot;(setval):);
  __asm__ volatile (&quot;&quot; ::: &quot;memory&quot;);}

static __inline__ uint32_t __iSeiRetVal(void) \
{ __asm__ volatile (&quot;CPSIE i\n\t&quot;&quot;dmb\n\t&quot;&quot;dsb\n\t&quot;&quot;isb\n\t&quot;); \
  __asm__ volatile (&quot;&quot; ::: &quot;memory&quot;); return 1; }   

static __inline__ uint32_t __iCliRetVal(void) \
{ __asm__ volatile (&quot;CPSID i\n\t&quot;&quot;dmb\n\t&quot;&quot;dsb\n\t&quot;&quot;isb\n\t&quot;); \
  __asm__ volatile (&quot;&quot; ::: &quot;memory&quot;); return 1; }   

static __inline__ void    __iSeiParam(const uint32_t *__s) \
{ __asm__ volatile (&quot;CPSIE i\n\t&quot;&quot;dmb\n\t&quot;&quot;dsb\n\t&quot;&quot;isb\n\t&quot;); \
  __asm__ volatile (&quot;&quot; ::: &quot;memory&quot;); (void)__s; }

static __inline__ void    __iCliParam(const uint32_t *__s) \
{ __asm__ volatile (&quot;CPSID i\n\t&quot;&quot;dmb\n\t&quot;&quot;dsb\n\t&quot;&quot;isb\n\t&quot;); \
  __asm__ volatile (&quot;&quot; ::: &quot;memory&quot;); (void)__s; }

static __inline__ void    __iRestore(const  uint32_t *__s) \
{ __set_primask(*__s); __asm__ volatile (&quot;dmb\n\t&quot;&quot;dsb\n\t&quot;&quot;isb\n\t&quot;); \
  __asm__ volatile (&quot;&quot; ::: &quot;memory&quot;); }


#define ATOMIC_BLOCK(type) \
for ( type, __ToDo = __iCliRetVal(); __ToDo ; __ToDo = 0 )

#define ATOMIC_RESTORESTATE \
uint32_t primask_save __attribute__((__cleanup__(__iRestore)))  = __get_primask()

#define ATOMIC_FORCEON \
uint32_t primask_save __attribute__((__cleanup__(__iSeiParam))) = 0
   
#define NONATOMIC_BLOCK(type) \
for ( type, __ToDo = __iSeiRetVal(); __ToDo ;  __ToDo = 0 )
   
#define NONATOMIC_RESTORESTATE \
uint32_t primask_save __attribute__((__cleanup__(__iRestore))) = __get_primask()

#define NONATOMIC_FORCEOFF \
uint32_t primask_save __attribute__((__cleanup__(__iCliParam))) = 0

#endif 
#endif
